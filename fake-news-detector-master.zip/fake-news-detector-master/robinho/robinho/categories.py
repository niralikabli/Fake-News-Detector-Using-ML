categories = {"fake_news": 2, "click_bait": 3, "extremely_biased": 4}

names = {2: "Fake News", 3: "Click Bait", 4: "Extremely Biased"}

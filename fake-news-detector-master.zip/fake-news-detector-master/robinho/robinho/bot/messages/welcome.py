def respond(_=None):
    return """
🇬🇧 Hello! I am Robinho, I'm a robot that tries to detect hoaxes and fake news, paste a text or a link here to check

🇧🇷 Olá! Eu sou o Robinho, eu sou um robô que tenta detectar boatos e fake news, cole um texto ou link aqui para checar

🇪🇸 ¡Hola! Yo soy Robinho, soy un robot que intenta detectar rumores y fake news, pega un texto o enlace aquí para verificar
"""

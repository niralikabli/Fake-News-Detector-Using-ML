This dataset was obtained from https://github.com/bhargaviparanjape/clickbait

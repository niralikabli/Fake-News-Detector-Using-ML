module Locale.Languages exposing (..)


type Language
    = Portuguese
    | English
    | Spanish

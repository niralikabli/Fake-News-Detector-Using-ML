DROP TABLE hoaxes

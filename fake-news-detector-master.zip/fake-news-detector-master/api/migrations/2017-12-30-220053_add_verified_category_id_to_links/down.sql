ALTER TABLE links DROP COLUMN verified_category_id

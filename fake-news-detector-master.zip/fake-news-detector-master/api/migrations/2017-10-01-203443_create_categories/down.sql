DROP TABLE categories

ALTER TABLE links
DROP COLUMN verified_clickbait_title,
DROP COLUMN removed;
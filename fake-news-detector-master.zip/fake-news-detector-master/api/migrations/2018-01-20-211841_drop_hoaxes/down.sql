CREATE TABLE hoaxes (
  id SERIAL PRIMARY KEY,
  content TEXT NOT NULL,
  uuid VARCHAR NOT NULL,
  ip VARCHAR NOT NULL
);

DELETE FROM links WHERE url = '8c4e24f3f8aaf82a22ec530b01d685b5';

INSERT INTO hoaxes(content, uuid, ip) VALUES (
  'Sempre tenha um saco de farinha (Atta) à mão na cozinha e deixe todos saberem onde está.

* NÃO DELETE SEM LEITURA PARA O FIM * 🙏

🔥Esta é uma verdadeira experiência de vida de uma mulher que se queimou ... 🔥.

Algum tempo atrás, eu estava cozinhando milho e derramado água fria na água fervente para ver se o milho estava pronto. Por engano eu mergulhei minha mão na água fervente .... !!

Um amigo meu que era um médico veterinário vietnamita tinha vindo para a casa. Então, como eu uivava de dores, ele me perguntou se eu tinha um saquinho de farinha de trigo em casa.

Eu derramei um pouco e ele colocou minha mão na farinha e me pediu para esperar por cerca de 10 minutos.

Ele me disse que no Vietnã havia um menino que uma vez queimou. Com o fogo sobre ele e em pânico alguém derramou um saco de farinha em todo o corpo para tentar extinguir o fogo. Mas não só o extinguido disparado não havia vestígios de queimaduras no garoto !!!!

No meu caso, coloquei minha mão no saco de farinha por 10 minutos e, em seguida, tirei-a e nem percebi nenhuma marca vermelha de queima depois disso. Além disso, absolutamente nenhuma dor.

Hoje eu coloco um saco de farinha na geladeira e sempre queiro eu uso a farinha. Na verdade, a farinha fria é muito melhor do que a temperatura ambiente.

Eu uso farinha e eu nunca tenho nenhum traço de queimaduras!

Eu mesmo tinha queimado a língua uma vez e coloquei a farinha por cerca de 10 minutos .... A dor parou.

Portanto, sempre tenha pelo menos uma saqueta de farinha na sua geladeira.

👌😊😊😊👍😊😊😊✌

A farinha tem a capacidade de absorver o calor e tem fortes propriedades antioxidantes. Assim, ajuda um paciente queimado se for aplicado dentro de 15 minutos.

Quando alguém compartilha algo de valor que é benéfico para você, você tem a obrigação moral de compartilhá-lo com os outros também. Então compartilhe isso com os outros. Tchau.
Reencaminhado como recebido ...', '123', '0.0.0.0'
);

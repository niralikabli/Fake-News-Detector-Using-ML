DROP TABLE hoaxes;

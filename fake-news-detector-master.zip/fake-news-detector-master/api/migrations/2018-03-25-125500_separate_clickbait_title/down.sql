ALTER TABLE votes DROP COLUMN clickbait_title

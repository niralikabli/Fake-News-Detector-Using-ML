INSERT INTO categories(name) VALUES ('Not News');

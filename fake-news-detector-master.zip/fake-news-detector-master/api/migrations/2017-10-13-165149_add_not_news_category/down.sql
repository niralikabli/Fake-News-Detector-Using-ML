DELETE FROM categories WHERE name = 'Not News';
